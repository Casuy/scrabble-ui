export interface IGameUser {
  name: string;
  score: number;
}
