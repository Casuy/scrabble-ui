export interface IGameVote {
  active: boolean;
  wordA: string;
  wordB: string;
}
