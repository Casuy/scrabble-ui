export interface IUser {
  name: string;
  inRoom?: boolean;
  inGame?: boolean;
}
