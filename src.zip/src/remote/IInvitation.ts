export interface IInvitation {
  roomId: number;
  invitor: string;
}
