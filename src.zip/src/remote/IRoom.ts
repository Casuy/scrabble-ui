export interface IRoom {
  id: number;
  users: string[];
}
